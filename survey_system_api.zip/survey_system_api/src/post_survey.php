<?php
include("db_connection.php");
$conn = db_connection();

header('application/json; charset=utf-8');

$_POST = json_decode(file_get_contents('php://input'), true);


$customer_name = $_POST["customer_name"];
$customer_age = $_POST["customer_age"];
$customer_location = $_POST["customer_location"];
$survey_date = $_POST["survey_date"];

$customer_query = "INSERT INTO `customers`(`customer_id`, `customer_name`, `customer_location`, `survey_date`, `customer_age`) VALUES 
(NULL,'$customer_name', '$customer_location', '$survey_date', '$customer_age')";
//$customer_exe = mysqli_query($conn, $customer_query);
if ($conn->query($customer_query) === TRUE) {
    $last_customer_id = $conn->insert_id;
    echo "\nNew customer created successfully. Last inserted ID is: " . $last_customer_id;
}

$outlet_name = $_POST["outlet_name"];
$outlet_query = "INSERT INTO `outlets`(`outlet_id`, `merchandiser_id`, `outlet_name`) 
VALUES (NULL,
        NULL,
        '$outlet_name')";
if ($conn->query($outlet_query) === TRUE) {
    $last_outlet_id = $conn->insert_id;
    echo "\nNew outlet created successfully. Last inserted ID is: " . $last_outlet_id;
}

$product_answer = $_POST["product_answer"];
$behavior_answer = $_POST["behavior_answer"];
$answer_query = "INSERT INTO `answers`(`answer_id`, `product_answer`, `behavior_answer`)
 VALUES (NULL,
         '$product_answer',
         '$behavior_answer')";
if ($conn->query($answer_query) === TRUE) {
    $last_answer_id = $conn->insert_id;
    echo "\nNew outlet created successfully. Last inserted ID is: " . $last_answer_id;
}


$start_date = $_POST["start_date"];
$end_date = $_POST["end_date"];
$status = $_POST["status"];
$survey_query = "INSERT INTO `surveys`(`survey_id`,
                      `outlet_id`,
                      `answer_id`,
                      `customer_id`, `start_date`, `end_date`, `status`)
VALUES (NULL,$last_outlet_id,$last_answer_id,'$last_customer_id','$start_date','$end_date','$status')";
$survey_exe = mysqli_query($conn, $survey_query);


//echo json_encode($exe);


?>
