<?php
include("db_connection.php");
$conn = dbconnection();

header('application/json; charset=utf-8');

$_POST = json_decode(file_get_contents('php://input'), true);

if($_POST['outlet_name']){
    $outlet_name = $_POST["outlet_name"];
    $query = "INSERT INTO `outlets` (`outlet_id`, `outlet_name`) VALUES (NULL, '$outlet_name')";
    $exe = mysqli_query($conn, $query);
    echo json_encode($exe );
}



?>
