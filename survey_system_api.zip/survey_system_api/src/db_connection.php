<?php
function dbconnection()
{
    $conn = mysqli_connect("localhost", "root", "", "survey_system");
    return $conn;
}

?>