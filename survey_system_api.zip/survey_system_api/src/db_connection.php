<?php
function db_connection()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "survey_system";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

//    $conn = mysqli_connect("localhost", "root", "", "survey_system");
    return $conn;
}

?>