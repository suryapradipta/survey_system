<?php
include("db_connection.php");
$conn = dbconnection();

header('application/json; charset=utf-8');

$_POST = json_decode(file_get_contents('php://input'), true);

if ($_POST['customer_name'] && $_POST['customer_age']
    && $_POST['customer_location']
    && $_POST['survey_date']) {
    $customer_name = $_POST["customer_name"];
    $customer_age = $_POST["customer_age"];
    $customer_location = $_POST["customer_location"];
    $survey_date = $_POST["survey_date"];

    $query = "INSERT INTO `customers`(`customer_id`, `customer_name`, `customer_location`, `survey_date`, `customer_age`) VALUES 
(NULL,'$customer_name', '$customer_location', '$survey_date', '$customer_age')";
    $exe = mysqli_query($conn, $query);
    echo json_encode($exe);
}


?>
