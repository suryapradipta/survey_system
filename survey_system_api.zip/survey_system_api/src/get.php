<?php
include("db_connection.php");
$conn = db_connection();

$query = "SELECT * FROM `surveys` WHERE 1";
$exe = mysqli_query($conn, $query);

$arr = [];
while ($row = mysqli_fetch_array($exe)) {
    $arr[] = $row;
}

print(json_encode($arr));
?>