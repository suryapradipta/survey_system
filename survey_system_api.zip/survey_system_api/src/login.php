<?php
include("db_connection.php");
$conn = dbconnection();


$username = $_POST['username'];
$password = $_POST['password'];

$query = "SELECT * FROM `merchandisers` WHERE username ='".$username."' AND password = '".$password."'";
$result = mysqli_query($conn, $query);
$count = mysqli_num_rows($result);

if($count == 1) {
    echo json_encode("Success");

} else {
    echo json_encode("Error");
}
?>